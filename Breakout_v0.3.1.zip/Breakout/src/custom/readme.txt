The objects in the custom directory require firmware other than 
StandardFirmata to be uploaded to the IOBoard. Custom objects are
not included in the minified Breakout.js file. They must be included
separately. See custom_examples for examples of use.
